/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_executor.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: luaraujo <luaraujo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/17 21:40:58 by jamendoe          #+#    #+#             */
/*   Updated: 2023/08/08 20:20:50 by luaraujo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "../../includes/minishell.h"

int	ft_run_executor(t_shell *shell, t_cmd *tmp_cmd, \
int tmp_pipe[2], int backup[2])
{
	int	end;

	end = 0;
	if (ft_handle_left_side(shell, tmp_cmd, tmp_pipe))
	{
		end = 1;
		ft_finish_executor(shell, tmp_cmd, backup, 0);
	}
	if (!end && ft_handle_right_side(shell, tmp_cmd, tmp_pipe, backup))
		end = 1;
	if (!end && ft_run_command(shell, tmp_cmd, tmp_pipe, backup))
		end = 2;
	// if (end)
	// 	return (EXIT_FAILURE);
	return (EXIT_SUCCESS);
}

int	ft_prepare_executor(t_shell *shell, int backup[2])
{
	backup[0] = dup(STDIN_FILENO);
	if (backup[0] < 0)
	{
		ft_clean_prompt(shell);
		ft_putendl_fd("bash: backup[0]: Bad file descriptor", STDERR_FILENO);
		return (EXIT_FAILURE);
	}
	backup[1] = dup(STDOUT_FILENO);
	if (backup[1] < 0)
	{
		close(backup[0]);
		ft_clean_prompt(shell);
		ft_putendl_fd("bash: backup[1]: Bad file descriptor", STDERR_FILENO);
		return (EXIT_FAILURE);
	}
	return (EXIT_SUCCESS);
}

int	ft_finish_executor(t_shell *shell, t_cmd *tmp_cmd, int backup[2], int reset)
{
	close(STDIN_FILENO);
	if (dup2(backup[0], STDIN_FILENO) < 0)
	{
		ft_clean_prompt(shell);
		ft_putendl_fd("bash: STDIN_FILENO: Bad file descriptor", STDERR_FILENO);
		return (EXIT_FAILURE);
	}
	close(backup[0]);
	if ((tmp_cmd->order_id && tmp_cmd->order_id == \
	shell->cmd_nbr - 1 && tmp_cmd->out) || reset)
	{
		close(STDOUT_FILENO);
		if (dup2(backup[1], STDOUT_FILENO) < 0)
		{
			close(backup[0]);
			ft_clean_prompt(shell);
			ft_putendl_fd("bash: STDOUT_FILENO: Bad file descriptor", STDERR_FILENO);
			return (EXIT_FAILURE);
		}
		close(backup[1]);
	}
	return (EXIT_SUCCESS);
}

int	ft_executor(t_shell *shell)
{
	t_cmd	*cmd;
	int		backup[2];
	int		tmp_pipe[2];
	pid_t	w_pid;
	int		status;
	int 	input;

	cmd = shell->command_list;
	if (ft_prepare_executor(shell, backup))
		return (EXIT_FAILURE);
	if (cmd->in)
		input = ft_check_redir_in(cmd);
	else
		input = dup(STDIN_FILENO);
	while (cmd)
	{
		close(STDIN_FILENO);
		if (dup2(input, STDIN_FILENO) < 0)
		{
			ft_putendl_fd("minishell: input: bad file descriptor", STDERR_FILENO);
			return (EXIT_FAILURE);
		}
		close(input);
		if (ft_run_executor(shell, cmd, tmp_pipe, backup))
		{
			if (!cmd->order_id && !cmd->next)
			{
				ft_finish_executor(shell, cmd, backup, 1);
				return (EXIT_FAILURE);
			}
		}
		if (!cmd->next)
			break ;
	}
	ft_finish_executor(shell, cmd, backup, 0);
	cmd = shell->command_list;
	if (!(shell->command_list->function_name > 0 && \
	!shell->command_list->redir && shell->cmd_nbr == 1))
	{
		while (cmd->order_id < shell->cmd_nbr - 1)
		{
			if (cmd->pid_cmd == 0)
				cmd = cmd->next;
			else
			{
				w_pid = waitpid (cmd->pid_cmd, &status, 0);
				if (w_pid > 0)
				{
					if (cmd->next)
						break ;
					cmd = cmd->next;
				}
				else if (w_pid == -1)
					return (EXIT_FAILURE);
				if (!WTERMSIG(status) && WEXITSTATUS(status))
					g_status = status >> 8;
			}
		}
	}
	return (EXIT_SUCCESS);
}
